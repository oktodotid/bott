<?php

use danog\MadelineProto\API;

class Userbot
{
    /**
     * VAR API
     */
    public $bot;

    public $update;
    public $settings;

    private static ?Userbot $instance = null;

    public function create($session, $settings)
    {
        $this->settings = $settings;
        $this->bot = new API($session, $settings);
        $this->bot->async(false);
        $this->bot->start();

        return $this;
    }

    public function run()
    {
        echo "userbot running...\n\n";

        $me = $this->bot->getSelf();
        $is = 0;
        // leave channel and groups
        $messages_Chats = $this->bot->getFullDialogs();
        foreach ($messages_Chats as $val) {
            if ($val['peer']['_'] == 'peerChannel') {
                $id = $val['peer']['channel_id'];
                echo $id . PHP_EOL;
                $Updates = $this->bot->channels->leaveChannel(['channel' => "-100" . $id]);
                //  print_r($Updates);
            }
        }

        // print_r($sentMessage);
        // $m = file_get_contents('pesan.json');
        // $text = json_decode($m,1)['pesan'];
        for ($i = 0; $i <= 500; $i++) {
            $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat01bot', 'message' => '/next']);
            sleep(10);
            $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat01bot', 'message' => 'Yang Mau Banyak Koleksi Indo 18+ Viral Terbaru Langsung Nih Ke @xeberg @ xeberg']);
            // $sentMessage = $this->bot->messages->sendMedia([
            //     'peer' => '@secretchat01bot',
            //     'media' => [
            //         '_' => 'inputMediaUploadedPhoto',
            //         'file' => 'https://teknospace.org/bot.png'
            //     ],
            //     'message' => 'ayo join, minggu depan bakal di closed ',
            //     'parse_mode' => 'Markdown'
            // ]);
            sleep(2);

            $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat02bot', 'message' => '/next']);
            sleep(10);
            // $sentMessage = $this->bot->messages->sendMedia([
            //     'peer' => '@secretchat02bot',
            //     'media' => [
            //         '_' => 'inputMediaUploadedPhoto',
            //         'file' => 'https://teknospace.org/bot.png'
            //     ],
            //     'message' => 'ayo join, minggu depan bakal di closed ',
            //     'parse_mode' => 'Markdown'
            // ]);
            $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat02bot', 'message' => 'Yang Mau Banyak Koleksi Indo 18+ Viral Terbaru Langsung Nih Ke @xeberg @ xeberg']);
            sleep(2);

            $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat03bot', 'message' => '/next']);
            sleep(10);
            // $sentMessage = $this->bot->messages->sendMedia([
            //     'peer' => '@secretchat03bot',
            //     'media' => [
            //         '_' => 'inputMediaUploadedPhoto',
            //         'file' => 'https://teknospace.org/bot.png'
            //     ],
            //     'message' => 'ayo join, minggu depan bakal di closed ',
            //     'parse_mode' => 'Markdown'
            // ]);
            $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat03bot', 'message' => 'Yang Mau Banyak Koleksi Indo 18+ Viral Terbaru Langsung Nih Ke @xeberg @ xeberg']);
            sleep(2);

            $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat04bot', 'message' => '/next']);
            sleep(10);
            // $sentMessage = $this->bot->messages->sendMedia([
            //     'peer' => '@secretchat04bot',
            //     'media' => [
            //         '_' => 'inputMediaUploadedPhoto',
            //         'file' => 'https://teknospace.org/bot.png'
            //     ],
            //     'message' => 'ayo join, minggu depan bakal di closed ',
            //     'parse_mode' => 'Markdown'
            // ]);
            $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat04bot', 'message' => 'Yang Mau Banyak Koleksi Indo 18+ Viral Terbaru Langsung Nih Ke @xeberg @ xeberg']);
            sleep(2);

            $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat05bot', 'message' => '/next']);
            sleep(10);
            // $sentMessage = $this->bot->messages->sendMedia([
            //     'peer' => '@secretchat05bot',
            //     'media' => [
            //         '_' => 'inputMediaUploadedPhoto',
            //         'file' => 'https://teknospace.org/bot.png'
            //     ],
            //     'message' => 'ayo join, minggu depan bakal di closed ',
            //     'parse_mode' => 'Markdown'
            // ]);
            $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat05bot', 'message' => 'Yang Mau Banyak Koleksi Indo 18+ Viral Terbaru Langsung Nih Ke @xeberg @ xeberg']);
            sleep(2);

            $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat06bot', 'message' => '/next']);
            sleep(10);
            // $sentMessage = $this->bot->messages->sendMedia([
            //     'peer' => '@secretchat06bot',
            //     'media' => [
            //         '_' => 'inputMediaUploadedPhoto',
            //         'file' => 'https://teknospace.org/bot.png'
            //     ],
            //     'message' => 'ayo join, minggu depan bakal di closed ',
            //     'parse_mode' => 'Markdown'
            // ]);
            $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat06bot', 'message' => 'Yang Mau Banyak Koleksi Indo 18+ Viral Terbaru Langsung Nih Ke @xeberg @ xeberg']);
            sleep(2);

            $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat07bot', 'message' => '/next']);
            sleep(10);
            // $sentMessage = $this->bot->messages->sendMedia([
            //     'peer' => '@secretchat07bot',
            //     'media' => [
            //         '_' => 'inputMediaUploadedPhoto',
            //         'file' => 'https://teknospace.org/bot.png'
            //     ],
            //     'message' => 'ayo join, minggu depan bakal di closed ',
            //     'parse_mode' => 'Markdown'
            // ]);
            $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat07bot', 'message' => 'Yang Mau Banyak Koleksi Indo 18+ Viral Terbaru Langsung Nih Ke @xeberg @ xeberg']);
            sleep(2);

            $Message = $this->bot->messages->sendMessage(['peer' => '@AnonyMeetBot', 'message' => '/next']);
            sleep(10);
            // $sentMessage = $this->bot->messages->sendMedia([
            //     'peer' => '@AnonyMeetBot',
            //     'media' => [
            //         '_' => 'inputMediaUploadedPhoto',
            //         'file' => 'https://teknospace.org/bot.png'
            //     ],
            //     'message' => 'ayo join, minggu depan bakal di closed ',
            //     'parse_mode' => 'Markdown'
            // ]);
            $Message = $this->bot->messages->sendMessage(['peer' => '@AnonyMeetBot', 'message' => 'Yang Mau Banyak Koleksi Indo 18+ Viral Terbaru Langsung Nih Ke @xeberg @ xeberg']);
            sleep(2);
            $Message = $this->bot->messages->sendMessage(['peer' => '@chatbot', 'message' => '/next']);
            sleep(10);
            // $sentMessage = $this->bot->messages->sendMedia([
            //     'peer' => '@chatbot',
            //     'media' => [
            //         '_' => 'inputMediaUploadedPhoto',
            //         'file' => 'https://teknospace.org/bot.png'
            //     ],
            //     'message' => 'ayo join, minggu depan bakal di closed ',
            //     'parse_mode' => 'Markdown'
            // ]);
            $Message = $this->bot->messages->sendMessage(['peer' => '@chatbot', 'message' => 'Yang Mau Banyak Koleksi Indo 18+ Viral Terbaru Langsung Nih Ke @xeberg @ xeberg']);
            sleep(2);

            echo ("$i. Sukses Send : @secretchat01 - 7bot - @AnonyMeetBot") . PHP_EOL;
            $this->bot->async(true);
        }
        // $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat01bot', 'message' => '/stop']);
        // $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat02bot', 'message' => '/stop']);
        // $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat03bot', 'message' => '/stop']);
        // $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat04bot', 'message' => '/stop']);
        // $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat05bot', 'message' => '/stop']);
        // $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat06bot', 'message' => '/stop']);
        // $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat07bot', 'message' => '/stop']);
        // $Message = $this->bot->messages->sendMessage(['peer' => '@AnonyMeetBot', 'message' => '/stop']);

        // $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat01bot', 'message' => '/stop']);

        // $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat02bot', 'message' => '/stop']);

        // $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat03bot', 'message' => '/stop']);

        // $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat04bot', 'message' => '/stop']);

        // $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat05bot', 'message' => '/stop']);

        // $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat06bot', 'message' => '/stop']);

        // $Message = $this->bot->messages->sendMessage(['peer' => '@secretchat07bot', 'message' => '/stop']);

        // $Message = $this->bot->messages->sendMessage(['peer' => '@AnonyMeetBot', 'message' => '/stop']);

        // $Message = $this->bot->messages->sendMessage(['peer' => '@chatbot', 'message' => '/stop']);

        // while (true) {
        //     $this->bot->setCallback(function ($update) use ($me) {
        //         /** ignore everything except messages */
        //         if (!isset($update['message']['message'])) {
        //             return;
        //         }

        //         /** ignore old updates if bot was down some time */
        //         if (round(time() - $update['message']['date']) > 60) {
        //             return;
        //         }

        //         /** print update in terminal */
        //         if ($this->settings['print_update'] ?? false) {
        //             print_r($update);
        //         } 

        //         $this->update = $update;

        //         /** load and run components */
        //         $this->loadComponents($this->bot, $update, @$update['message']['message'], $me, @$update['message']['user_id'], @$update['message']['from_id']);
        //     });

        //     $this->bot->async(true);
        //     $this->bot->loop();
        // }
    }


    private function loadComponents(API $bot, array $update, $message = null, array $me, $userId = null, $fromId = null)
    {
        foreach (glob(__DIR__ . '/../components/*/component.php') as $component) {
            try {
                include $component;
            } catch (\Throwable $th) {
                $name = basename($component);
                echo PHP_EOL . "[ERROR] Component `{$name}`: " . $th->getMessage() . PHP_EOL;
            }
        }
    }

    public static function getInstance(): Userbot
    {
        if (static::$instance === null) {
            static::$instance = new static();
        }

        return static::$instance;
    }

    private function __construct()
    {
    }

    private function __wakeup()
    {
    }

    private function __clone()
    {
    }
}
