<?php

require __DIR__ . '/madeline.php';
require __DIR__ . '/core/Userbot.php';
require __DIR__ . '/core/Helpers.php';
// require __DIR__. '/core/***';
