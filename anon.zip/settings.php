<?php

return [
    'app_info' => [
        'api_id' => 23308718,
        'api_hash' => '85073164b866a25c1fbfcab97c4dc602',
    ],
    'logger' => [
        'logger' => 0,
    ],
    'print_update' => true,
];

